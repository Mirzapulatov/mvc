<?php
/**
 * Config data base
 */
$host = "localhost"; // Host
$dbuser = "postgres"; //Data Base User
$dbpass = "123456"; //Data Base Password
$dbname = "test"; //Data Base Name
