<?php
define('AdminName','Admin'); //Login adminPanel
define('AdminPassword','password'); //Password adminPanel