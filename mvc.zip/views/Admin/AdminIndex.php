<div class="content">
    <div class="content_resize">
        <div class="mainbar">
            <div class="article">
                <a href="/admin/blog/"> <h2><span>Управление блогом</span></h2></a>
                <a href="/admin/news/"> <h2><span>Управление новостями</span></h2></a>
                <a href="/admin/portfolio/"> <h2><span>Управление портфолио</span></h2></a>
                <a href="/admin/contacts/"> <h2><span>Почта</span></h2></a>
            </div>
        </div>