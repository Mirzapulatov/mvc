<div class="content">
    <div class="content_resize">
        <div class="mainbar">

    <div class="article">
        <div style="float:left;width: 50%;text-align: center;">
            <a href="/service/mobile" class="rm">
                <img src="/common/images/service_mobile.png" width="200" alt="" class="fl" />
            </a>
            <br/>
            <p><h2>Создание мобильных приложений</h2></p>
            <p>Наша основная специализация – разработка мобильных приложений iPhone, Android и Windows Phone.</p>
        </div>

        <div style="float:left;width: 50%;text-align: center;">
            <a href="/service/support" class="rm">
            <img src="/common/images/service_support.png" width="200" alt="" class="fl" />
                </a>
            <br/>
            <p><h2>Техническая поддержка</h2></p>
            <p>Для нас мобильные проекты не заканчиваются на стадии реализации.</p>
        </div>
        <div class="clr"></div>

        <div style="float:left;width: 50%;text-align: center;">
            <a href="/service/web" class="rm">
            <img src="/common/images/service_design.png" width="200" alt="" class="fl" />
            </a>
            <br/>
            <p><h2>WEB - разработка</h2></p>
            <p>Адаптивный сайт представляет собой симбиоз веб-сайта и мобильного сайта.</p>
        </div>

        <div style="float:left;width: 50%;text-align: center;">
            <a href="/service/seo" class="rm">
            <img src="/common/images/service_seo.png" width="200" alt="" class="fl" />
            </a>
            <br/>
            <p><h2>Продвижение сайтов</h2></p>
            <p>Продвижение сайтов Симферополь</p>
        </div>
        <div class="clr"></div>

        <p></p>
        <div class="clr"></div>
    </div>
</div>