
<div class="clr"></div>
</div>
</div>
<div class="fbg">
    <div class="fbg_resize">
        <div class="col c1">
            <h2><span>Галерея</span></h2>
            <a href="/portfolio/25"><img src="/common/files/portfolio/1.jpg" width="60" height="60" alt="" class="gal" /></a>
            <a href="/portfolio/26"><img src="/common/files/portfolio/2.jpg" width="60" height="60" alt="" class="gal" /></a>
            <a href="/portfolio/27"><img src="/common/files/portfolio/3.jpg" width="60" height="60" alt="" class="gal" /></a>
            <a href="/portfolio/28"><img src="/common/files/portfolio/4.jpg" width="60" height="60" alt="" class="gal" /></a>
            <a href="/portfolio/29"><img src="/common/files/portfolio/5.jpg" width="60" height="60" alt="" class="gal" /></a>
            <a href="/portfolio/30"><img src="/common/files/portfolio/6.jpg" width="60" height="60" alt="" class="gal" /></a> </div>
        <div class="col c2">
            <h2><span>Партнеры </span></h2>
            <ul class="fbg_ul">
                <li><a href="http://google.com">Google inc.</a></li>
                <li><a href="http://vk.com">VK inc.</a></li>
                <li><a href="http://yandex.ru">Yandex inc.</a></li>
            </ul>
        </div>
        <div class="col c3">
            <h2><span>Контакты</span> </h2>
            <p class="contact_info"> <span>Адрес:</span> 1458 TemplateAccess, USA<br />
                <span>Телефон:</span> +123-1234-5678<br />
                <span>FAX:</span> +458-4578<br />
                <span>Другое:</span> +301 - 0125 - 01258<br />
                <span>E-mail:</span> <a href="#">mail@yoursitename.com</a> </p>
        </div>