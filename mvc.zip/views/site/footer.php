<div class="clr"></div>
</div>
</div>
<div class="footer">
    <div class="footer_resize">
        <p class="lf">Copyright &copy; <a href="#">RGame</a>. Page gen.: <?php echo microtime()-$pageGen; ?></p>
        <p class="rf">Get More <a target="_blank" href="http://www.free-css.com/">Free CSS Templates</a> By <a target="_blank" href="http://www.dreamtemplate.com/">DreamTemplate</a></p>
        <div style="clear:both;"></div>
    </div>
</div>
</div>
</body>
</html>