<?php
echo 'error 404';